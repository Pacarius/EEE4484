// using UnityEngine;

// public class TestTrigger : MonoBehaviour{
//     void OnTriggerEnter(Collider other){
//         other.GetComponent<IRailTriggerable>().OnRailTriggered(GetComponent<Collider>());
//     }
// }