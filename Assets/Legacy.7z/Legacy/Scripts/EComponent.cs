using UnityEngine;
namespace Legacy
{
    public class EComponent : MonoBehaviour
    {
        public GameObject Positive;
        public GameObject Negative;

    }
}