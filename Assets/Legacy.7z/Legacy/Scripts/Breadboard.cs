using System;
using System.Collections.Generic;
using UnityEngine;
namespace Legacy
{

    public class Breadboard : MonoBehaviour
    {
        //public Rails[] Rails;
        public Material passthroughMaterial;
        public Material positiveMaterial;
        public Material negativeMaterial;
        public Material avoidMaterial;
        public Material defaultMaterial;
    }
}