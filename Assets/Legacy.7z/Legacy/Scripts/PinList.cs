using System.Collections.Generic;
using UnityEngine;

namespace Legacy
{
    public class PinList : MonoBehaviour
    {
        public List<Esp32Pin> pins = new();
    }
}